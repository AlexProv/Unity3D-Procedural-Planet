﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class tempScript : MonoBehaviour {
	public SphericalCoords sphericalCoords;
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetButtonDown ("Fire1")) {
			SphericalCoords sc = new SphericalCoords (transform.position);
			//SphericalCoords serc = new SphericalCoords (2,3,unit.degree);
			Debug.Log (sc.toString());
			Debug.Log(sc.toCartesian());
			Debug.Log(sc.toDMS());
		}
	}
}
