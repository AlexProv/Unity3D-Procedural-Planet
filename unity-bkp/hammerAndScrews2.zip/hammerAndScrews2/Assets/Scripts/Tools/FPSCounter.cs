﻿using UnityEngine;
using System.Collections;

public class FPSCounter : MonoBehaviour
{
	float fps, frames, lastInterval;
	public float updateRate = 0.5f	;

	void Start ()
	{
		lastInterval = Time.realtimeSinceStartup;
		frames = 0;
	}

	void Update ()
	{
		++frames;
		float now = Time.realtimeSinceStartup;
		if(now > lastInterval + updateRate)
		{
			fps = frames / (now - lastInterval);
			frames = 0;
			lastInterval = now;
			Debug.Log("fps = " + fps);
		}
	}

	public float GetFPS()
	{
		return fps;
	}
}
