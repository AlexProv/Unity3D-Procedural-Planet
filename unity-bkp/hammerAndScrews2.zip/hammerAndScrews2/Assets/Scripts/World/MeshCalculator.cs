﻿using UnityEngine;
using System;
using System.Collections;
using System.Threading;

public class MeshCalculator {
	//mesh data
	public Vector3[] vertex;
	public int[] triangles; 
	public Vector3[] normals;
	public Vector2[] uv;
	public Color[] colors;
	//sizing data
	private int type;
	private int dimensions = 3;
	protected int resolution;
	//lod data
	protected int lodLevel;
	private Vector2 offset;
	private float lodSize;
	//coloring data
	private Gradient coloring;
	//recursion data
	protected MeshCalculator parent;
	private gridVertexMethod method;
	private lodChunkData chunkData;
	private MeshManager manager;
	public string id;
	private VoxcelWorld world;
	//threading data
	private ManualResetEvent calculationDone;
	int doneCounter;
	bool bottomAchived;

	
	public MeshCalculator(MeshCalculator parent, gridVertexMethod method, lodChunkData chunkData, Vector2 offset, ManualResetEvent calculationDone,MeshManager manager,string id, VoxcelWorld world){
		this.world = world;
		this.method = method;
		this.manager = manager;
		doneCounter = 0;	
		bottomAchived = false;
		if(parent != null){
			this.parent = parent;
			this.id = id;
			lodLevel = parent.lodLevel+ 1;
			lodSize = parent.lodSize / 2;
			this.offset = offset;
			this.resolution = parent.resolution;
			this.type = parent.type;
			
		}
		else{
			initRoot(lodChunkData.MAX_LOD,calculationDone,id);
		}
		this.chunkData = chunkData;
		if(this.chunkData.ldx[0].data == null){ //is leaf so make the grid
			bottomAchived = true;
			//if(!this.manager.gameDictAsID(this.id))
				//ThreadPool.QueueUserWorkItem(this.CreateGrid);
				CreateGrid(null);
		}
		else {
			initChild(method,chunkData);
		}
	}
	
	public void doneCheker(){
		lock(this){
			doneCounter+=1;
			if(doneCounter == 4 || bottomAchived){
				if(parent != null)
					parent.doneCheker();
				else{
					//send msg all done 
					calculationDone.Set();
				}
			}
		}
	}
	
	private void initRoot(int lodStop, ManualResetEvent calculationDone,string id){
		this.calculationDone = calculationDone;
		this.id = id;
		lodLevel = 1;
		lodSize = 2; 
		offset = Vector2.zero;
		resolution = 20;
	}
		
	private lodChunkData[] getLodForData(lodChunkData data){
		lodChunkData[] temp = new lodChunkData[4];
		for(int i = 0; i < 4; i++){
			temp[data.ldx[i].index] = data.ldx[i].data;
		}
		return temp;
	}	
	
	private void initChild(gridVertexMethod method,lodChunkData data)
	{
		lodChunkData[] lodArray = getLodForData(data);
		MeshCalculator ms = new MeshCalculator(this,method,lodArray[0],topLeftOffset(offset,lodSize),null,manager, this.id + MeshManager.chunkName[0] + data.lodLevel,world);
					   ms = new MeshCalculator(this,method,lodArray[1],topRightOffset(offset,lodSize),null,manager, this.id + MeshManager.chunkName[1] + data.lodLevel,world);
					   ms = new MeshCalculator(this,method,lodArray[2],bottomLeftOffset(offset,lodSize),null,manager, this.id + MeshManager.chunkName[2] + data.lodLevel,world);
					   ms = new MeshCalculator(this,method,lodArray[3],bottomRightOffset(offset,lodSize),null,manager, this.id + MeshManager.chunkName[3] + data.lodLevel,world);
	}

	private void CreateGrid (System.Object threadContext){
		NoiseMethod methodNoise = Noise.methods[(int)type][dimensions - 1];//WARNING: dimensions tjr egale a zero
		
		vertex = new Vector3[(resolution + 1) * (resolution + 1)];
		colors = new Color[vertex.Length];
		normals = new Vector3[vertex.Length];
		uv = new Vector2[vertex.Length];
		float stepSize = 1f / resolution;
		for (int v = 0, z = 0; z <= resolution; z++) {
			for (int x = 0; x <= resolution; x++, v++) {
				Vector3 cubeCoords = (method(x,z,stepSize,lodLevel,offset,lodSize));
				//offset doit etre ramener a -1 a 1
				
				Vector3 sphereCoords = cubeToSphere(cubeCoords);
				float sample = Noise.Sum(methodNoise, sphereCoords,world.param.frequency, world.param.octaves, 
				                         world.param.lacunarity, world.param.persistence).value;
				
				colors[v] = world.param.coloring.Evaluate(sample + 0.5f);//WARNING: coloring tjr egale a null
				
				sample *= 0.4f;
				//vertices[v] = (sphereCoords * sample + sphereCoords*10)*PlanetWorld.noiseParam[0].radius;
				vertex[v] = (sphereCoords * sample + sphereCoords*10).normalized;
				vertex[v] *= world.param.radius;
				//colors[v] = Color.black;
				normals[v] = Vector3.up;
				
				uv[v] = new Vector2(x * stepSize, z * stepSize);				
			}
		}
		
		triangles = new int[resolution * resolution * 6];
		for (int t = 0, v = 0, y = 0; y < resolution; y++, v++) {
			for (int x = 0; x < resolution; x++, v++, t += 6) {
				triangles[t] = v;
				triangles[t + 1] = v + resolution + 1;
				triangles[t + 2] = v + 1;
				triangles[t + 3] = v + 1;
				triangles[t + 4] = v + resolution + 1;
				triangles[t + 5] = v + resolution + 2;
			}
		}
		manager.register(id,this);
		doneCheker();
	}
	
	private Vector3 cubeToSphere(Vector3 v){
		float xC = v.x*v.x; 
		float yC = v.y*v.y;
		float zC = v.z*v.z;
		
		float x = v.x * Mathf.Sqrt( 1.0f - (yC /2.0f) - (zC/2.0f) + (zC*yC/3.0f));
		float y = v.y * Mathf.Sqrt( 1.0f - (xC /2.0f) - (zC/2.0f) + (zC*xC/3.0f));
		float z = v.z * Mathf.Sqrt( 1.0f - (xC /2.0f) - (yC/2.0f) + (yC*xC/3.0f));
		
		return new Vector3(x,y,z);
	}
	
	private static Vector2 topLeftOffset(Vector2 parentOffset, float lodSize){
		return parentOffset + new Vector2(0f, lodSize / 2.0f);}
	private static Vector2 topRightOffset(Vector2 parentOffset, float lodSize){
		return parentOffset + new Vector2(lodSize / 2.0f, lodSize / 2.0f);}
	private static Vector2 bottomLeftOffset(Vector2 parentOffset, float lodSize){
		return parentOffset;}
	private static Vector2 bottomRightOffset(Vector2 parentOffset, float lodSize){
		return parentOffset + new Vector2(lodSize / 2.0f, 0f);}
}
