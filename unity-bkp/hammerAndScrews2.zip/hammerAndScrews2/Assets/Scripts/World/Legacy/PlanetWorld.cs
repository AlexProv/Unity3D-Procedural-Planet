﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum ChunckPosition{
	topLeft,
	topRight,
	bottomLeft,
	bottomRight,
	
};

public delegate Vector3 gridVertexMethod(int i, int j, float stepSize, int lodLevel,Vector2 offset,float lodSize);

public enum gridMethodsNames{
	topGridVertex,
	bottomGridVertex,
	leftGridVertex,
	rightGridVertex,
	forwardGridVertex,
	backGridVertex,
};

public class PlanetWorld : MonoBehaviour {

	public static gridVertexMethod[] gridMethods = {
		topGridVertex,
		bottomGridVertex,
		leftGridVertex,
		rightGridVertex,
		forwardGridVertex,
		backGridVertex,
	};
	
	public NoiseMethodType type;
	public Vector3 rotation;
	
	public PlanetChunk PlanetChunkPrefab; 

	private int currentResolution;
	
	private Mesh mesh;
	private Vector3[] vertices;
	private Vector3[] normals;
	private Color[] colors;
	private float hRatio;
	
	private PlanetChunk[] chunks;
	static public NoiseParam[] noiseParam;
	public NoiseParam noiseParamBig;
	public NoiseParam noiseParamMedium;
	public NoiseParam noiseParamSmall;
	static public Transform rootTransform; 
	
	//LOD must be taken into account here
	public static Vector2 DefaultRange = new Vector2(-1.0f,1.0f);
	private static Vector3 topGridVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.x,1f,answer.y);
	}
	private static Vector3 bottomGridVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.y,-1f,answer.x);
	}
	private static Vector3 leftGridVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(-1f,answer.x,answer.y);
	}
	private static Vector3 rightGridVertex(int i, int j,float stepSize, int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(1f,answer.y,answer.x);
	}
	private static Vector3 forwardGridVertex(int i, int j,float stepSize, int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.y,answer.x,1f);
	}
	private static Vector3 backGridVertex(int i, int j,float stepSize, int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.x,answer.y,-1f);
	}
	
	private static Vector2 ijToVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer;
		if(lodLevel == 1 ) answer = new Vector2(i * stepSize-0.5f,j * stepSize - 0.5f)*2; 
		else{
			answer = new Vector2(-1 + i*stepSize*lodSize, -1 + j*stepSize*lodSize);
		}
		answer += offset;
		return answer;
	}
	public GameObject tester;
	public void Refresh (){
		List<GameObject> children = new List<GameObject>();
		foreach (Transform child in transform) children.Add(child.gameObject);
		children.ForEach(child => Destroy(child));
		
		noiseParam = new NoiseParam[3];
		noiseParam[0] = noiseParamBig;
		noiseParam[1] = noiseParamMedium;
		noiseParam[2] = noiseParamSmall;
		
		
		rootTransform = this.transform;
		chunks = new PlanetChunk[6];
		DefaultRange = new Vector2(-1,1);
		int i = 0;
		
		PlanetChunk p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		lodChunkData ld = new lodChunkData(null,0,new Vector3(0,1,0),tester.transform.position,"root");
		//p.Initialize(null,gridMethods[(int)gridMethodsNames.topGridVertex],lodsStop,Vector2.zero,PlanetChunkPrefab);
		p.Initialize(null,gridMethods[(int)gridMethodsNames.topGridVertex],ld,PlanetChunkPrefab);
		chunks[i++] = p;
		/*
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(null,gridMethods[(int)gridMethodsNames.bottomGridVertex],lodsStop,Vector2.zero,PlanetChunkPrefab);
		chunks[i++] = p;
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(null,gridMethods[(int)gridMethodsNames.leftGridVertex],lodsStop,Vector2.zero,PlanetChunkPrefab);
		chunks[i++] = p;
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(null,gridMethods[(int)gridMethodsNames.rightGridVertex],lodsStop,Vector2.zero,PlanetChunkPrefab);
		chunks[i++] = p;
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(null,gridMethods[(int)gridMethodsNames.forwardGridVertex],lodsStop,Vector2.zero,PlanetChunkPrefab);
		chunks[i++] = p;
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(null,gridMethods[(int)gridMethodsNames.backGridVertex],lodsStop,Vector2.zero,PlanetChunkPrefab);
		chunks[i++] = p;*/
	}
	private void OnEnable () {
		Refresh();
	}
		
	void createPool(){
		PlanetChunkPrefab.CreatePool(1000);
		PlanetChunk p = PlanetChunkPrefab.Spawn();
	}
	
}
