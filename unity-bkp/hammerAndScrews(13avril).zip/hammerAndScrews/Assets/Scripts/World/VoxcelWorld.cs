﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class VoxcelWorld : MonoBehaviour {

	public PlanetVoxcel planetVoxcelPrefab;
	public GameObject player;
	public NoiseParam param;
	
	MeshManager topManager;
	MeshManager bottomManager;
	MeshManager leftManager;
	MeshManager rightManager;
	MeshManager forwardManager;
	MeshManager rearManager;
		
	public void Awake(){
		planetVoxcelPrefab.CreatePool(1000);
				
		topManager = new MeshManager("topRoot", player.transform.position,new Vector3(0,1,0), this, topGridVertex,planetVoxcelPrefab);
		bottomManager = new MeshManager("bottomRoot", player.transform.position,new Vector3(0,-1,0), this, bottomGridVertex,planetVoxcelPrefab);
		leftManager = new MeshManager("leftRoot", player.transform.position, new Vector3(-1,0,0), this, leftGridVertex,planetVoxcelPrefab);
		rightManager = new MeshManager("rightRoot", player.transform.position, new Vector3(1,0,0), this, rightGridVertex,planetVoxcelPrefab);
		forwardManager = new MeshManager("forwardRoot", player.transform.position, new Vector3(0,0,1), this, forwardGridVertex,planetVoxcelPrefab);
		rearManager = new MeshManager("rearRoot", player.transform.position, new Vector3(0,0,-1), this, backGridVertex,planetVoxcelPrefab);//*/
	}
	
	public void deleteObjects(List<GameObject> data){
		foreach(GameObject i in data){
			i.Recycle();
		}
	}
	
	public void OnDestroy()
	{
		Debug.Log("WORLD DESTROYER");
	}
	
	public void Update(){
		topManager.Update(player.transform.position);
		bottomManager.Update(player.transform.position);
		leftManager.Update(player.transform.position);
		rightManager.Update(player.transform.position);
		forwardManager.Update(player.transform.position);
		rearManager.Update(player.transform.position);//*/
	}
	
	#region util methods
	public static Vector2 DefaultRange = new Vector2(-1.0f,1.0f);
	private static Vector3 topGridVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.x,1f,answer.y);
	}
	private static Vector3 bottomGridVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.y,-1f,answer.x);
	}
	private static Vector3 leftGridVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(-1f,answer.x,answer.y);
	}
	private static Vector3 rightGridVertex(int i, int j,float stepSize, int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(1f,answer.y,answer.x);
	}
	private static Vector3 forwardGridVertex(int i, int j,float stepSize, int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.y,answer.x,1f);
	}
	private static Vector3 backGridVertex(int i, int j,float stepSize, int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer = ijToVertex(i,j,stepSize,lodLevel,offset,lodSize);
		return new Vector3(answer.x,answer.y,-1f);
	}
	
	private static Vector2 ijToVertex(int i, int j,float stepSize,int lodLevel,Vector2 offset,float lodSize){
		Vector2 answer;
		if(lodLevel == 1 ) answer = new Vector2(i * stepSize-0.5f,j * stepSize - 0.5f)*2; 
		else{
			answer = new Vector2(-1 + i*stepSize*lodSize, -1 + j*stepSize*lodSize);
		}
		answer += offset;
		return answer;
	}
	#endregion
}
