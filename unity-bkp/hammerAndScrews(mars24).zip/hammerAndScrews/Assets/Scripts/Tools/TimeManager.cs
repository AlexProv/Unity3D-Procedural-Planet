﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

[RequireComponent(typeof(FPSCounter))]
public class TimeManager : MonoBehaviour
{
    //public FPSCounter fpsCounter;
    public float minFps = 30f;
    static ManualResetEvent waithandler = new ManualResetEvent(false);
    FPSCounter fpsCounter;


    void Start()
    {
		fpsCounter = gameObject.GetComponent<FPSCounter>();
    }

    void Update ()
    {
        if(breakCondition())
        {
            waithandler.Reset();

        }
        else
        {
            waithandler.Set();

        }

    }
    public void breakPoint()
    {
        waithandler.WaitOne();
    }

    bool validateFPS()
    {
        return fpsCounter.GetFPS() > minFps;
    }

    bool terrainGenerated()
    {
        //TODO
        return true;
    }


    bool breakCondition()
    {
        return !validateFPS() || !terrainGenerated();
    }

    /*IEnumerator pauseObject(int id)
    {
        while(true)
        {
            if(!BreakCondition())
                break;
            yield return new WaitForSeconds (5);
        }
    }//*/


    /*Object getThread(int id)
    {
        return tpool[id];
    }//*/
}