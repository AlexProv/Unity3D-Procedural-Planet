﻿using UnityEngine;
using System.Collections;

public class SwitchObject : MonoBehaviour {

	public GameObject ObjectToActivate;

	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.C))
		{
			gameObject.SetActive(false);
			ObjectToActivate.SetActive(true);
		}
	}
}
