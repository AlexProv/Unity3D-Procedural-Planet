﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Rigidbody))]
public class GravityBody : MonoBehaviour
{

    public GravityAttractor attractor;
    public int grounded;

    void Start ()
    {
        Rigidbody rb = GetComponent<Rigidbody>();
        rb.WakeUp();
        rb.useGravity = false;
    }

    void OnCollisionEnter(Collision c)
    {
        if(c.gameObject.layer == 10)
        {
            ++grounded;
        }
    }

   void OnCollisionExit(Collision c)
    {
        if(c.gameObject.layer == 10 && grounded > 0)
        {
            --grounded;
        }
    }

    void FixedUpdate()
    {
        if(attractor)
        {
            attractor.Attract(this);
        }
    }
}