using UnityEngine;
using System.Collections;

[RequireComponent (typeof (Rigidbody))]
[RequireComponent (typeof (CapsuleCollider))]

public class PlayerControllerPlanet : MonoBehaviour {
	public float mouseSensitivity = 250.0f;
	public float speed = 10.0f;
	public float jumpForce = 220.0f;
	public float gravity = 10.0f;
	float rotationVertLook;

	Vector3 move;
	Vector3 velocity;

	Vector3 smoothMoveVelocity;

	public float maxVelocityChange = 10.0f;
	public bool canJump = true;
	public float jumpHeight = 2.0f;
	//bool grounded = false;
	Rigidbody rb;
	Transform cameraTransform;
	Vector3 moveAmount;

	public LayerMask groundedMask;

	void Start()
	{
		rb = GetComponent<Rigidbody>();
		rb.freezeRotation = true;
		rb.useGravity = false;
	}
	void Awake()
	{
		//Screen.lockCursor = true;
		cameraTransform = GetComponentInChildren<Camera>().transform;
	}

	void Update()
	{
		//Camera look
		transform.Rotate(Vector3.up * Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime);
		rotationVertLook += Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;
		rotationVertLook = Mathf.Clamp(rotationVertLook,-60.0f,60.0f);
		cameraTransform.localEulerAngles = Vector3.left * rotationVertLook;

		Vector3 moveAmount = new Vector3(Input.GetAxisRaw("Horizontal"),0, Input.GetAxisRaw("Vertical")).normalized * speed;
		move = Vector3.SmoothDamp(move,moveAmount,ref smoothMoveVelocity,0.15f);

		if (Input.GetButtonDown("Jump"))
		{
			rb.AddForce(transform.up * jumpForce);
		}

	}

	void FixedUpdate()
	{



        Vector3 localMove = transform.TransformDirection(move) * Time.fixedDeltaTime;
        GetComponent<Rigidbody>().MovePosition(GetComponent<Rigidbody>().position + localMove);
	}

	/*void OnCollisionStay(Collision colli)
	{
		grounded = true;
	}

	void OnCollisionExit (Collision colli)
	{
		grounded = false;
	}*/
}