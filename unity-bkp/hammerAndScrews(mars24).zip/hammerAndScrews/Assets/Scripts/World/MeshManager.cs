﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

public class MeshManager : MonoBehaviour{//les voisin deverais etre gere dans cette classe;
	ConcurrentDict <string,lodChunkData> newDict;
	ConcurrentDict <string, lodChunkData> oldDict;
	ConcurrentDict <string, lodChunkData> drawDict;
	gridVertexMethod method;
	public GameObject Tester;
	
	private Vector3 oldPos; 
	public void Update(){
		if(Vector3.Distance(Tester.transform.position,oldPos) > 0.5f){
			lodChunkData.cpt = 0;
			updateNewPosition(Tester.transform.position);
			oldPos = Tester.transform.position;
			Debug.Log(lodChunkData.cpt);
		}
	}
	
	//lodChunkData ld = new lodChunkData(null,0,new Vector3(0,1,0),tester.transform.position,"root");								
	public void Awake(){
		Init("");
		oldPos = Vector3.zero;
		updateNewPosition(Vector3.zero);
	}
	public void Init(string rootId){
		newDict = new ConcurrentDict<string, lodChunkData>();
		oldDict = new ConcurrentDict<string, lodChunkData>();
		drawDict = new ConcurrentDict<string, lodChunkData>();
	}
	
	public void updateNewPosition(Vector3 position){
		Debug.Log("sanity");
		ManualResetEvent mre = new ManualResetEvent(false);
		lodChunkData ld = new lodChunkData(null,0,new Vector3(0,1,0),Tester.transform.position,"root",mre,this,true);								
		ManualResetEvent[] mreArray = {mre};
		WaitHandle.WaitAll(mreArray);
		
		mre = new ManualResetEvent(false);
		MeshCalculator mc = new MeshCalculator(null,method,ld,Vector2.zero,mre);//WARNING method tjr egale a null
		//need to go check if already exist? 
		WaitHandle.WaitAll(mreArray);
		//TODO: Mesh cree
		Debug.Log("check");
	}
	
	public bool register(string id, lodChunkData data){
		lock(this){
			lodChunkData existingData; 
			bool answer = false;
			
			if(oldDict.TryGetValue(id, out existingData)){
				newDict.Add(id,existingData);
				oldDict.Remove(id);
				answer = true;
			}
			
			else{
				newDict.Add(id,data);
				drawDict.Add(id,data);
			}
			//*/
			return answer;
		}
	}
	
	private string[] getListToClean(){
		return oldDict.GetKeysArray();
	}
}

