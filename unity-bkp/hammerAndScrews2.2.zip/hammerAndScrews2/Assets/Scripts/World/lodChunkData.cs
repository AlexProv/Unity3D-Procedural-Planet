﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Threading;


public class lodChunkData  {
	public static int MAX_LOD = 4; //pas encore CONST pour le devloppement 
	
	static public float[] lodDistances = {4,2,1,0.5f}; //index = LodLevel -1 
	//static public float[] lodDistances = {95,90.2f,91,1}; //index = LodLevel -1 
	static public  string[] liveChunkId = {};
	
	public int lodLevel;
	public Vector3 position;
	private Vector3 camPos;
	public float size;

	public lodChunkData parent;
	public string id;//sera utile pour ne pas avoir a re-generer une tuile si elle est deja instancier
	public List<IndexDistance>  ldx;
	
	private int ratioIndex;
	private int doneCounter;
	private static bool bottomAchived;//TODO: not static
	
	ManualResetEvent manualSwitch;
	MeshManager manager;
	public int uninitializedChilds = 4;
	public static int cpt = 0;

	private static Vector3[,] ratioBases = {
		{new Vector3(-1,0,1),new Vector3(1,0,1),new Vector3(-1,0,-1),new Vector3(1,0,-1)},
		{new Vector3(-1,1,0),new Vector3(1,1,0),new Vector3(-1,-1,0),new Vector3(1,-1,0)},
		{new Vector3(0,-1,1),new Vector3(0,1,1),new Vector3(0,-1,-1),new Vector3(0,1,-1)}
	};
	
	public void doneCheker(){
		lock(this){
			doneCounter+=1;
			if(doneCounter == 4 || bottomAchived){
				if(parent != null)
					parent.doneCheker();
				else{
					//send msg all done 
					manualSwitch.Set();
				}
			}
		}
	}
	
	void initroot (String id){
		size = 2;
		lodLevel = 1;
		this.id = id;
		bottomAchived = false;
	}
	
	public lodChunkData(lodChunkData parent,int ratioIndex, Vector3 position, Vector3 camPos,string id, ManualResetEvent manualSwitch, MeshManager manager,bool isRoot){
		cpt+=1;
		this.parent = parent;
		this.ratioIndex = ratioIndex;
		this.position = position;
		this.camPos = camPos;
		this.id = id;
		this.manualSwitch = manualSwitch;
		this.manager = manager;
		//initialize(parent,ratioIndex,position,camPos,id);
		if(isRoot)
			//ThreadPool.QueueUserWorkItem(this.initializeParallel);
			this.initializeParallel(null);
		else
			initializeParallel(null);
	} 
	
	private void initializeParallel(System.Object threadObject){
		doneCounter = 0;
		if(parent == null){
			initroot(id);
		}
		else{
			lodLevel = parent.lodLevel+1;
			size = parent.size/2.0f;
		}
		
		if(lodLevel <= MAX_LOD){
			//create and test kids 
			float ratio = size / 4.0f;
			//calcule des distance pour chaque enfant future
			float gtDistance =  Vector3.Distance(position + (ratioBases[ratioIndex,0] * ratio), camPos);
			float dtDistance = Vector3.Distance(position + (ratioBases[ratioIndex,1] * ratio), camPos);
			float gdDistance = Vector3.Distance(position + (ratioBases[ratioIndex,2] * ratio), camPos);
			float ddDistance = Vector3.Distance( position + (ratioBases[ratioIndex,3] * ratio), camPos);
			
			ldx = new List<IndexDistance>();
			ldx.Add(new IndexDistance(0,gtDistance));
			ldx.Add(new IndexDistance(1,dtDistance));
			ldx.Add(new IndexDistance(2,gdDistance));
			ldx.Add(new IndexDistance(3,ddDistance));
			ldx.Sort();
			
			if(lodLevel == MAX_LOD){
				bottomAchived = true;
				manager.register(id,this);
				doneCheker();
			}
			else{
				if((lodLevel+1 < getLodStop(ldx[0].distance)) || !bottomAchived){
					foreach(IndexDistance i in ldx){
						i.data = factoryByIndexParallele(i.index,position,ratio,camPos,manualSwitch,manager);
					}
				}
				else
				{
					manager.register(id,this);
				}
			}
		}	
	}
	
	public lodChunkData(lodChunkData parent,int ratioIndex, Vector3 position, Vector3 camPos,string id)
	{
		this.parent = parent;
		this.ratioIndex = ratioIndex;
		this.position = position;
		this.camPos = camPos;
		this.id = id;
		//initializeParallel(null);
		initialize(parent,ratioIndex,position,camPos,id);
	}  
	
	private void initialize(lodChunkData parent,int ratioIndex, Vector3 position, Vector3 camPos,string id){
		doneCounter = 0;
		if(parent == null){
			initroot(id);
		}
		else{
			this.parent = parent;
			lodLevel = parent.lodLevel+1;
			size = parent.size/2.0f;
			this.id = id;
		}
		this.position = position;
		
		if(lodLevel <= MAX_LOD){
			//create and test kids 
			float ratio = size / 4.0f;
			//calcule des distance pour chaque enfant future
			float gtDistance =  Vector3.Distance(position + (ratioBases[ratioIndex,0] * ratio), camPos);
			float dtDistance = Vector3.Distance(position + (ratioBases[ratioIndex,1] * ratio), camPos);
			float gdDistance = Vector3.Distance(position + (ratioBases[ratioIndex,2] * ratio), camPos);
			float ddDistance = Vector3.Distance( position + (ratioBases[ratioIndex,3] * ratio), camPos);
			
			ldx = new List<IndexDistance>();
			ldx.Add(new IndexDistance(0,gtDistance));
			ldx.Add(new IndexDistance(1,dtDistance));
			ldx.Add(new IndexDistance(2,gdDistance));
			ldx.Add(new IndexDistance(3,ddDistance));
			ldx.Sort();
			
			if(lodLevel == MAX_LOD){
				bottomAchived = true;
				//doneCheker();
				//manager.register(id,this);
			}
			if((lodLevel+1 <= getLodStop(ldx[0].distance)) || !bottomAchived){
				foreach(IndexDistance i in ldx){
					i.data = factoryByIndex(i.index,position,ratio,camPos);
				}
			}
		}
	}
	//cette fonctione s'occupe de cree le bon objet (haut gauche bas, gauche etc.)
	private lodChunkData factoryByIndexParallele(int index, Vector3 positionParent,float ratio, Vector3 campos,ManualResetEvent manualSwitch, MeshManager manager){
		return new lodChunkData(this,ratioIndex,positionParent + (ratioBases[ratioIndex,index] * ratio),campos,
								this.id + MeshManager.chunkName[index] + lodLevel.ToString()  + "",manualSwitch,manager,false);
	}
	
	private lodChunkData factoryByIndex(int index, Vector3 positionParent,float ratio, Vector3 campos){
		string parentID = "r";
		if(parent != null)
			parentID = parent.id;
		return new lodChunkData(this,ratioIndex,positionParent + (ratioBases[ratioIndex,index] * ratio),campos,
								parentID + MeshManager.chunkName[index] + lodLevel.ToString()  + "");
	}
	
	//retourne le lod que deverais avoir une tuile a la distance qu'elle se trouve.
	int getLodStop(float deltaDistance){
		int lodStop = 1;
		for(int i =lodLevel; (i <= lodDistances.Length-1 && deltaDistance < lodDistances[i-1]); i++){//bessoin d'avoir une autre condition pour que sa drill down au max au moins 1 fois
			lodStop = i+1; 
		}
		return lodStop;
	}
}
				
//classe qui permet le pre-calcule des enfants sans les instancier. 
public class IndexDistance : IComparable<IndexDistance>{
	public int index;
	public float distance; 
	public lodChunkData data;
	
	public IndexDistance(int i, float d){
		index = i;
		distance = d;
	}
	
	public int CompareTo(IndexDistance other){
		if(distance < other.distance)
			return -1;
		else 
			return  1;
	}
}


