﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;


public class MeshManager{//les voisins deverais etre geres dans cette classe;
	ConcurrentDict <string,lodChunkData> lodDict;
	ConcurrentDict <string, MeshCalculator> drawDict;//a creer
	ConcurrentDict< string, GameObject> gameDict; // en vie
	PlanetVoxcel pollManager; 
	Vector3 lodPosition;
	gridVertexMethod method;
	VoxcelWorld world; 
	private Vector3 oldPos; 
	private string rootId;
	private Vector3 position;


	public static readonly string[] chunkName = { "GH", "DH", "GB", "DB" };
	
	public void Update(Vector3 position){
		this.position = position;
		if(Vector3.Distance(this.position,oldPos) > 0.5f){
			lodChunkData.cpt = 0;
			oldPos = position;
			updateNewPosition();
		}
	}
	
	public MeshManager(string rootId, Vector3 position, Vector3  lodPosition, VoxcelWorld world, gridVertexMethod method, PlanetVoxcel pollManager){
		oldPos = Vector3.zero;
		this.lodPosition = lodPosition;
		this.rootId = rootId;
		this.world = world;
		this.position = position;
		this.pollManager = pollManager;
		this.method = method;

		lodDict = new ConcurrentDict<string, lodChunkData>();
		drawDict = new ConcurrentDict<string, MeshCalculator>();
		gameDict = new ConcurrentDict<string, GameObject>();
	}
	
	private void updateNewPosition(){
		//Time manager
		ManualResetEvent mre = new ManualResetEvent(false);
		lodChunkData ld = new lodChunkData(null,0,lodPosition,position,rootId,mre,this,true);								
		mre.WaitOne();
		
		ManualResetEvent mreCal = new ManualResetEvent(false);
		MeshCalculator mc = new MeshCalculator(null,method,ld,Vector2.zero,mreCal,this,rootId,world);
		//need to go check if already exist? 
		mreCal.WaitOne();
		//TODO: Mesh cree
		//undraw
		//draw
		drawing();

		cleaner();
		resetForNextPass();
	}
	
	public void register(string id, lodChunkData data){
		lodDict.Add(id,data);
	}
	
	public void register(string id, MeshCalculator data){
		drawDict.Add(id,data);
	}
	
	private void resetForNextPass(){
		lodDict = new ConcurrentDict<string, lodChunkData>();
		drawDict = new ConcurrentDict<string, MeshCalculator>();
	}
	
	private void drawing(){
		foreach(KeyValuePair<string,MeshCalculator> i in drawDict){
			GameObject outer;
			if(!gameDict.TryGetValue(i.Key,out outer)){
				PlanetVoxcel spawn = pollManager.Spawn();
				spawn.Inititalize(i.Value);
				gameDict.Add(i.Key, spawn.gameObject);
			}
		}
	}
	
	private void cleaner(){
		List<GameObject> toRecycle = new List<GameObject>();
		lock(gameDict){
			foreach(string key in gameDict.dict.Keys.ToArray())
			{
				if(!lodDict.ContainsKey(key))
				{
					toRecycle.Add(gameDict[key]);
					//gameDict[key].Recycle();		
					gameDict.Remove(key);
				}
			}
		}

		world.deleteObjects(toRecycle);
	}

	public bool gameDictAsID(string id)
	{
		return gameDict.ContainsKey(id);
	}
}

