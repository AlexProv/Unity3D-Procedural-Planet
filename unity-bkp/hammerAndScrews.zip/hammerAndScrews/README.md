# hammerAndScrews
Projet d'informatique 2

Le projet consiste à développer un prototype de jeu vidéo fait à l'aide de la plateforme Unity. La base serait tout d'abord de créer un jeu de type carré de sable (Sandbox) où le monde sera généré de manière procédurale avec l’algorithme du bruit de simplex ; par la suite, des villages seront générés de manières aléatoires. Nous allons avoir besoin d’un contrôleur de personnage pour que l'utilisateur puisse se déplacer dans le monde généré et de donner au joueur la capacité de créer des bâtiments et des véhicules pour se promener dans ce monde. Aussi on pense avoir le temps de crée d’un système de ressource pour qu'il puisse interagir avec l'environnement une fois dans le jeu. 
