using UnityEngine;
using System.Collections;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class PlanetVoxcel : MonoBehaviour {
	Mesh mesh;
	MeshFilter filter; 
	
	void OnEnable(){
		filter = GetComponent<MeshFilter>();
		filter.mesh = null;
		mesh = new Mesh();
	}
	
	public void Inititalize(MeshCalculator data){
		mesh.vertices = data.vertex;
		mesh.triangles = data.triangles;
		mesh.normals = data.normals;
		mesh.uv = data.uv;
		mesh.colors = data.colors;
		filter.mesh = mesh;
		filter.sharedMesh = mesh;
	}
}
