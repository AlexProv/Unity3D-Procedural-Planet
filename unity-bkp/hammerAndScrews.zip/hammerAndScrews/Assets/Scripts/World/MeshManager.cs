﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading;


public class MeshManager{//les voisin deverais etre gere dans cette classe;
	
	ConcurrentDict <string,lodChunkData> newDict;
	ConcurrentDict <string, lodChunkData> oldDict;
	ConcurrentDict <string, MeshCalculator> drawDict;
	ConcurrentDict <string, lodChunkData> calDict; 
	Dictionary< string, GameObject> gameDict;
	PlanetVoxcel pollManager; 
	Vector3 lodPosition;
	gridVertexMethod method;
	VoxcelWorld world; 
	private Vector3 oldPos; 
	private string rootId;
	private Vector3 position;
	
	public void Update(Vector3 position){
		this.position = position;
		if(Vector3.Distance(position,oldPos) > 0.5f){
			lodChunkData.cpt = 0;
			updateNewPosition();
			oldPos = position;
		}
	}
	
	public MeshManager(string rootId, Vector3 position, Vector3  lodPosition, VoxcelWorld world, gridVertexMethod method, PlanetVoxcel pollManager){
		oldPos = Vector3.zero;
		this.lodPosition = lodPosition;
		this.rootId = rootId;
		this.world = world;
		this.position = position;
		this.pollManager = pollManager;
		this.method = method;
		newDict = new ConcurrentDict<string, lodChunkData>();
		oldDict = new ConcurrentDict<string, lodChunkData>();
		drawDict = new ConcurrentDict<string, MeshCalculator>();
		calDict = new ConcurrentDict<string, lodChunkData>();
		gameDict = new Dictionary<string, GameObject>();
	}
	
	/*
		bon le prob c'est que oldDict (le dict dont on doit reclyler les obj) est pas bon faut changer la logique de quand est ce que il est updater et reserter a newDict 
		en se moment aucun obj est recyler car le dict est pas bon
		
	*/ 
	
	private void updateNewPosition(){
		ManualResetEvent mre = new ManualResetEvent(false);
		lodChunkData ld = new lodChunkData(null,0,lodPosition,position,rootId,mre,this,true);								
		ManualResetEvent[] mreArray = {mre};
		WaitHandle.WaitAll(mreArray); // boucle a l'infenei ici
		
		ManualResetEvent mreCal = new ManualResetEvent(false);
		ManualResetEvent[] mreArrayCal = {mreCal};
		MeshCalculator mc = new MeshCalculator(null,method,ld,Vector2.zero,mreCal,this,rootId,world);//WARNING method tjr egale a null
		//need to go check if already exist? 
		WaitHandle.WaitAll(mreArrayCal); // dossent work it dossent wait
		//TODO: Mesh cree
		//undraw
		//draw
		drawing();
		//rebuild dict
		cleaner();
		resetForNextPass();
		
	}
	
	public bool register(string id, lodChunkData data){
	//logic draw vs no draw here
		lock(this){
			lodChunkData existingData; 
			bool answer = false;
			if(oldDict.TryGetValue(id, out existingData)){
				newDict.Add(id,existingData);
				oldDict.Remove(id);
				answer = true;
			}
			else{
				newDict.Add(id,data);
				calDict.Add(id,data); // crask ici
			}
			//*/
			return answer;
		}
	}
	
	public bool register(string id, MeshCalculator data){
		lock(this){
			lodChunkData existingData; 
			bool answer = false;
			if(oldDict.TryGetValue(id, out existingData)){
				answer = true;
			}
			else{
				drawDict.Add(id,data);
			}
			//*/
			return answer;
		}
	}
	
	private void resetForNextPass(){
		//cleaner(); send msg to destroy cleaner
		oldDict = newDict;
		newDict = new ConcurrentDict<string, lodChunkData>();
		calDict = new ConcurrentDict<string, lodChunkData>();
		drawDict = new ConcurrentDict<string, MeshCalculator>();
	}
	
	private void drawing(){
		foreach(KeyValuePair<string,MeshCalculator> i in drawDict){ //prob draw est vide
			PlanetVoxcel spawn = pollManager.Spawn();
			spawn.Inititalize(i.Value);
		}
		//return toDraw;
	}
	
	private void cleaner(){
		List<GameObject> answer = new List<GameObject>();
		foreach(KeyValuePair<string, lodChunkData> i in oldDict){
			GameObject value = gameDict[i.Key];
			gameDict.Remove(i.Key);
			answer.Add(value);
		}
		world.deleteObjects(answer);
	}
	
	
	
	private void applyValueToObject(MeshCalculator data, GameObject obj){
		MeshFilter mf = obj.GetComponent<MeshFilter>() as MeshFilter;
		Mesh m = obj.GetComponent<Mesh>() as Mesh;
		
		m.vertices = data.vertex;
		m.colors = data.colors;
		m.uv = data.uv;
		m.triangles = data.triangles;
		m.triangles = data.triangles;
	}
}

