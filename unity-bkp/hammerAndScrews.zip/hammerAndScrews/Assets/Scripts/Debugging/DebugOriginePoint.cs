﻿using UnityEngine;
using System.Collections;

public class DebugOriginePoint : MonoBehaviour {
	public float size;
	public Color color = Color.red;
	public void OnDrawGizmos()
	{
		Gizmos.color = color;
		Gizmos.DrawSphere(transform.position,size);
	}
}
