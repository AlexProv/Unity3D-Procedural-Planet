﻿using UnityEngine;
using System;
using System.Collections;

public enum unit
{
	radian,
	degree
};

[Serializable]
public class SphericalCoords
{
	#region Constants
	const float PI = Mathf.PI;
	const float TWO_PI = Mathf.PI * 2;
	const float HALF_PI = Mathf.PI / 2;
	const float DEGREE_BASE = 360;
	const float HALF_DEGREE_BASE = DEGREE_BASE / 2;
	const float RIGHT_ANGLE_DEG = DEGREE_BASE / 4;

	#endregion Constants

	#region Variables
	private float elevationD, elevationR;
	private float polarD, polarR;
	private float elevation, polar;
	#endregion Variables

	#region Properties
	public float Elevation
	{
		get
		{
			return elevation;
		}
		set
		{
			if(UnitDefaultType == unit.degree)
			{
				if(value >= -RIGHT_ANGLE_DEG && value <= RIGHT_ANGLE_DEG)
					elevation = value;
				else
					throw new Exception("Elevation must be betheen -90 and 90.");
			}
			else
			{
				Polar = polar;
				if(value >= -(HALF_PI) && value <= (HALF_PI))
					elevation = value;
				else
					throw new Exception("Elevation must be between -Pi/2 and pi/2.");
			}
		}
	}

	//Polar in degree
	public float Polar
	{
		get
		{
			return polar;
		}
		set
		{
			if(UnitDefaultType == unit.radian)
			{
				polar = value % (TWO_PI);
				if(polar > PI)
				{
					polar = polar - TWO_PI;
				}
			}
			else
			{
				polar =  value % DEGREE_BASE;
				if(polar > DEGREE_BASE)
				{
					polar = polar - DEGREE_BASE;
				}
			}
		}
	}

	public unit UnitDefaultType{ get; private set; }

	public float Radius{ get; private set; }
	#endregion Properties
	
	#region Constructor
	public SphericalCoords(float polar, float elevation) : this(polar, elevation, 0f, unit.radian) {}
	
	public SphericalCoords(float polar, float elevation, float radius) : this(polar, elevation, radius, unit.radian) {}
	
	public SphericalCoords(float polar, float elevation, unit unitType) : this(polar, elevation, 0f, unitType) {}

	public SphericalCoords(float polar, float elevation, float radius, unit unitType)
	{
		UnitDefaultType = unitType;
		Radius = radius;

		Polar = polar;
		Elevation = elevation;

	}

	public SphericalCoords(Vector3 vect)
	{
		if(vect.x == 0f)
			vect.x = Mathf.Epsilon;
		Radius = vect.magnitude;
		
		Polar = Mathf.Atan(vect.z / vect.x);
		
		if(vect.x < 0f)
		{
			if(vect.z < 0f)
			{
				Polar -= PI;
			}
			else
			{
				polar += PI;
			}
		}
		Elevation = Mathf.Asin(vect.y / Radius);
	}
	#endregion Constructor

	#region Methods
	public string toDMS()
	{
		//Il y a peut-etre des problemes avec les floor de negatif
		//Maybe utiliser CeilToInt sur les negatifs
		string ans = "";
		float conv = UnitDefaultType == unit.radian ? DEGREE_BASE / PI : 1;
		float tmpDeg = Polar * conv;
		int deg = Mathf.FloorToInt(tmpDeg);
		tmpDeg = (tmpDeg - deg) * 60;
		int min = Mathf.FloorToInt(tmpDeg);
		int sec = Mathf.RoundToInt((tmpDeg - min) * 60);
		ans += "[" + deg + "°" + min + "'" + sec + "\"" + " longitude]";

		tmpDeg = Elevation * conv;
		deg = Mathf.FloorToInt(tmpDeg);
		tmpDeg = (tmpDeg - deg) * 60;
		min = Mathf.FloorToInt(tmpDeg);
		sec = Mathf.RoundToInt((tmpDeg - min) * 60);
		ans += " [" + deg + "°" + min + "'" + sec + "\"" + " latitude]";
		return ans;
	}
	public Vector3 toCartesian()
	{
		float a = Radius * Mathf.Cos(elevation);
		return new Vector3(a * Mathf.Cos(polar), Radius * Mathf.Sin(elevation), a * Mathf.Sin(polar));
	}

	public void setDegreeAsDefault()
	{
		UnitDefaultType = unit.degree;
		Polar = Polar * DEGREE_BASE / PI;
		Elevation = Elevation * DEGREE_BASE / PI;
	}

	public void setRadianAsDefault()
	{
		UnitDefaultType = unit.radian;
		Polar = Polar * PI / DEGREE_BASE;
		Elevation = Elevation * PI / DEGREE_BASE;
	}

	public string toString()
	{
		if (UnitDefaultType == unit.radian)
			return "Radius: " + Radius + " - Polar: " + Polar / PI + "Pi - Elevation: " + Elevation / PI + "Pi";
		else
			return "Radius: " + Radius + " - Polar: " + Polar + " - Elevation: " + Elevation;
	}
	#endregion Methods
}
