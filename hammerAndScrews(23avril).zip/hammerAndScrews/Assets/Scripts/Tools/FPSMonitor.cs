﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

[RequireComponent(typeof(FPSCounter))]
public class FPSMonitor : MonoBehaviour
{
    //static ManualResetEvent waithandler = new ManualResetEvent(true);
    public float minFps = 30f;
    FPSCounter fpsCounter;


    void Awake()
    {
		fpsCounter = gameObject.GetComponent<FPSCounter>();
    }

    /*void Update ()
    {
        if(PauseGeneration())
        {
            waithandler.Reset();

        }
        else
        {
            waithandler.Set();

        }

    }
    public void breakPoint()
    {
        waithandler.WaitOne();
    }*/

    bool fpsIsValide()
    {
        return fpsCounter.GetFPS() > minFps;
    }

	/*bool fieldGenerated()
    {
    }*/


    public bool PauseGeneration()
    {
		return !fpsIsValide(); //|| !fieldGenerated();
    }
}