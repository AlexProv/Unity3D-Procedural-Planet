﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

[RequireComponent(typeof(FPSMonitor))]
public class TestBreakPoint : MonoBehaviour
{
    public static List<GameObject> objs = new List<GameObject>();
	//GameObject basicCube;
	Thread taskThread;
	FPSMonitor timeManager;


	void Awake ()
	{

		timeManager = gameObject.GetComponent<FPSMonitor>();
		if(gameObject.GetComponents<FPSMonitor>().Length != 1) throw new UnityException();
		//basicCube = (GameObject)Resources.Load ("/Prefabs/BasicCubePrefab");
		//basicCube = Instantiate(basicCube, transform.position, transform.rotation) as GameObject;

		taskThread = new Thread(createTask) {Name = "Create Task"};
		taskThread.Start();
	}

	void createTask()
    {
		while(true)
		{
			Debug.Log("ALLO");
			//timeManager.breakPoint();
			Debug.Log("BYE");
        }
    }
}
