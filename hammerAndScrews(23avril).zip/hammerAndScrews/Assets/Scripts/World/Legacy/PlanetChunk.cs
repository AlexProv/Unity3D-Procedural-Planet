/*using UnityEngine;
using System.Collections;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class PlanetChunk : MonoBehaviour {

	
	public int resolution = 3;
	
	public Vector2 offset;
	public float lodSize;
	
	public Vector3 rotation;
	public float strength = 1f;
	public bool damping;
	public float frequency = 1f;
	public int octaves = 1;
	public float lacunarity = 2f;
	public float persistence = 0.5f;
	public int dimensions = 3;
	public NoiseMethodType type;
	public Gradient coloring;
	public bool coloringForStrength;
	public bool analyticalDerivatives;
	public bool showNormals;
	
	private Mesh mesh;
	private Vector3[] vertices;
	private Vector3[] normals;
	private Color[] colors;
	
	public PlanetChunk PlanetChunkPrefab; 
	protected int lodLevel;
	PlanetChunk parent; 
	
	
	private void OnEnable () {
		if (mesh == null) {
			mesh = new Mesh();
			mesh.name = "Surface Mesh";
			GetComponent<MeshFilter>().mesh = mesh;
		}
		//refresh();
	}
	

	public void Initialize (PlanetChunk parent,gridVertexMethod method,int lodStop,Vector2 offset,PlanetChunk prefab)
	{
		PlanetChunkPrefab = prefab;
		resolution = PlanetWorld.noiseParam[0].resolution;
		Initialize(parent, method,lodStop, offset);
	}
	public void Initialize (PlanetChunk parent,gridVertexMethod method,int lodStop,Vector2 offset)
	{
		this.transform.parent = PlanetWorld.rootTransform;
		if(parent != null){
			this.parent = parent;
			lodLevel = parent.lodLevel + 1;
			lodSize = parent.lodSize / 2;
			this.offset = offset;
		}
		else {
			initRoot(lodStop);
		}
		
		if(lodLevel == lodStop)
			CreateGrid(method);	
		else
		{
			initChild(method,lodStop);
		}
	}
	
	public void Initialize (PlanetChunk parent,gridVertexMethod method,LodChunkData chunkData,PlanetChunk prefab)
	{
		PlanetChunkPrefab = prefab;
		resolution = PlanetWorld.noiseParam[0].resolution;
		//ou bien implementer la resolution dans chunkData mais pour le debugage en se moment c'est beaucoup plus facile de l'avoir la 
		Vector2 offset = Vector2.zero;
		Initialize(parent, method,chunkData, offset);
	}
	public void Initialize (PlanetChunk parent,gridVertexMethod method,LodChunkData chunkData,Vector2 offset)
	{
		this.transform.parent = PlanetWorld.rootTransform;
		if(parent != null){
			this.parent = parent;
			lodLevel = parent.lodLevel+ 1;
			lodSize = parent.lodSize / 2;
			this.offset = offset;
		}	
		else{
			initRoot(LodChunkData.MAX_LOD);
		}

		if(chunkData.ldx[0].data == null){ //is leaf so make the grid 
			CreateGrid(method);	
		}
		else{
			initChild(method,chunkData);
		}
	}
	
	private void initRoot(int lodStop){
		lodLevel = 1;
		lodSize = 2; 
		offset = Vector2.zero;
	}
	
	private void initChild(gridVertexMethod method,LodChunkData data)
	{			
		if(parent != null)
			PlanetChunkPrefab = parent;
		LodChunkData[] lodArray = getLodForData(data);
		PlanetChunk p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodArray[0],topLeftOffset(offset,lodSize));
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodArray[1],topRightOffset(offset,lodSize));
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodArray[2],bottomLeftOffset(offset,lodSize));
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodArray[3],bottomRightOffset(offset,lodSize));
		
	}
	
	private LodChunkData[] getLodForData(LodChunkData data){
		LodChunkData[] temp = new LodChunkData[4];
		for(int i = 0; i < 4; i++){
			temp[data.ldx[i].index] = data.ldx[i].data;
		}
		return temp;
	}
	
	private void initChild(gridVertexMethod method,int lodStop)
	{
		PlanetChunk p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodStop,topLeftOffset(offset,lodSize));
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodStop,topRightOffset(offset,lodSize));
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodStop,bottomLeftOffset(offset,lodSize));
		
		p = Instantiate(PlanetChunkPrefab) as PlanetChunk;
		p.Initialize(this,method,lodStop,bottomRightOffset(offset,lodSize));
	}
	
	
	private static Vector2 topLeftOffset(Vector2 parentOffset, float lodSize)
	{
		return parentOffset + new Vector2(0f, lodSize / 2.0f);
	}
	private static Vector2 topRightOffset(Vector2 parentOffset, float lodSize)
	{
		return parentOffset + new Vector2(lodSize / 2.0f, lodSize / 2.0f);
	}
	private static Vector2 bottomLeftOffset(Vector2 parentOffset, float lodSize)
	{
		return parentOffset;		
	}
	private static Vector2 bottomRightOffset(Vector2 parentOffset, float lodSize)
	{
		return parentOffset + new Vector2(lodSize / 2.0f, 0f);
	}

	private Vector3 cubeToSphere(Vector3 v){
		float xC = v.x*v.x; 
		float yC = v.y*v.y;
		float zC = v.z*v.z;
		
		float x = v.x * Mathf.Sqrt( 1.0f - (yC /2.0f) - (zC/2.0f) + (zC*yC/3.0f));
   		float y = v.y * Mathf.Sqrt( 1.0f - (xC /2.0f) - (zC/2.0f) + (zC*xC/3.0f));
   		float z = v.z * Mathf.Sqrt( 1.0f - (xC /2.0f) - (yC/2.0f) + (yC*xC/3.0f));
   		
   		return new Vector3(x,y,z);
	}
	
	private void cubeToSphere(ref Vector3 v){
		float xC = v.x*v.x; 
		float yC = v.y*v.y;
		float zC = v.z*v.z;
		
		float x = v.x * Mathf.Sqrt( 1.0f - (yC /2.0f) - (zC/2.0f) + (zC*yC/3.0f));
		float y = v.y * Mathf.Sqrt( 1.0f - (xC /2.0f) - (zC/2.0f) + (zC*xC/3.0f));
		float z = v.z * Mathf.Sqrt( 1.0f - (xC /2.0f) - (yC/2.0f) + (yC*xC/3.0f));
		
		v.x = x;
		v.y = y;
		v.z = z;
	}
	
	private void squareToCircle(ref Vector2 v){
		float xC = v.x*v.x; 
		float yC = v.y*v.y;
		v.x = v.x*Mathf.Sqrt(1-yC/2.0f);
		v.y = v.y*Mathf.Sqrt(1-xC/2.0f);
	}
	
	private Vector2 squareToCircle(Vector2 v){
		float xC = v.x*v.x; 
		float yC = v.y*v.y;
		float x = v.x * Mathf.Sqrt(1-yC/2);
		float y = v.y * Mathf.Sqrt(1-xC/2);
		return new Vector2(x,y);
	}
	
	private Vector2 toZeroToOne(Vector2 v){
		return new Vector2 ((v.x+1.0f)/2.0f , ((v.y+1)/2.0f));
	}
	private Vector2 toMinusOneToOne(Vector2 v){
		return( new Vector2(v.x*2.0f - 1, v.y*2.0f - 1));
	}
	
	
	private void CreateGrid (gridVertexMethod method) {
		NoiseMethod methodNoise = Noise.methods[(int)type][dimensions - 1];
		
		mesh.Clear();
		vertices = new Vector3[(resolution + 1) * (resolution + 1)];
		colors = new Color[vertices.Length];
		normals = new Vector3[vertices.Length];
		Vector2[] uv = new Vector2[vertices.Length];
		float stepSize = 1f / resolution;
		//float maxRange = getMaxRangeValue(method,resolution,stepSize,lodLevel,offset);
		for (int v = 0, z = 0; z <= resolution; z++) {
			for (int x = 0; x <= resolution; x++, v++) {
				Vector3 cubeCoords = (method(x,z,stepSize,lodLevel,offset,lodSize));
				//offset doit etre ramener a -1 a 1
				
				Vector3 sphereCoords = cubeToSphere(cubeCoords);
				float sampleBig = Noise.Sum(methodNoise, sphereCoords,PlanetWorld.noiseParam[0].frequency, PlanetWorld.noiseParam[0].octaves, 
				                         PlanetWorld.noiseParam[0].lacunarity, PlanetWorld.noiseParam[0].persistence).value;
				                         
				//float sampleMedium = Noise.Sum(methodNoise, sphereCoords,PlanetWorld.noiseParam[1].frequency, PlanetWorld.noiseParam[1].octaves, 
				//                            PlanetWorld.noiseParam[1].lacunarity, PlanetWorld.noiseParam[1].persistence).value;
				
				//float sampleSmall = Noise.Sum(methodNoise, sphereCoords,PlanetWorld.noiseParam[2].frequency, PlanetWorld.noiseParam[2].octaves, 
				//                            PlanetWorld.noiseParam[2].lacunarity, PlanetWorld.noiseParam[2].persistence).value;
				                            
				float sample = sampleBig * PlanetWorld.noiseParam[0].strength + sampleBig * PlanetWorld.noiseParam[1].strength + sampleBig * PlanetWorld.noiseParam[2].strength;
				/*
				if((sphereCoords*10).magnitude > (sphereCoords * sample + sphereCoords*10).magnitude)
					colors[v] = coloring.Evaluate(sample + 0.5f);
				else
					colors[v] = PlanetWorld.noiseParam[1].coloring.Evaluate(sample + 0.5f);*\
				colors[v] = coloring.Evaluate(sample + 0.5f);
				
				sample *= 0.4f;
				//vertices[v] = (sphereCoords * sample + sphereCoords*10)*PlanetWorld.noiseParam[0].radius;
				vertices[v] = (sphereCoords * sample + sphereCoords*10).normalized;
				vertices[v] *= PlanetWorld.noiseParam[0].radius;
				//colors[v] = Color.black;
				normals[v] = Vector3.up;
				
				uv[v] = new Vector2(x * stepSize, z * stepSize);
			}
		}
		
		// doit etre capable d'aller chercher le lod voisin. 
	 	// transforme juste pour ton travail tableau 2D pour allez chercher les edeges
	 	// un coup que les 4 edeges sont trouver faire un interpretation lineaire selon le lod voisins. 
		
		mesh.vertices = vertices;
		mesh.colors = colors;
		mesh.normals = normals;
		mesh.uv = uv;
		//mesh.RecalculateNormals();
		int[] triangles = new int[resolution * resolution * 6];
		for (int t = 0, v = 0, y = 0; y < resolution; y++, v++) {
			for (int x = 0; x < resolution; x++, v++, t += 6) {
				triangles[t] = v;
				triangles[t + 1] = v + resolution + 1;
				triangles[t + 2] = v + 1;
				triangles[t + 3] = v + 1;
				triangles[t + 4] = v + resolution + 1;
				triangles[t + 5] = v + resolution + 2;
			}
		}
		mesh.triangles = triangles;
	}
}*/