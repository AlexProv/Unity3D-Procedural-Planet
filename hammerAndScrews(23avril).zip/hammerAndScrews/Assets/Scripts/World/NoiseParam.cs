﻿using UnityEngine;
using System.Collections;
using System;

[Serializable]
public class NoiseParam {

	[Range(1, 200)]
	public int resolution = 10;
	[Range(0f, 1f)]
	public float strength = 1f;
	public bool damping;
	[Range(1, 12)]
	public float frequency = 1f;
	[Range(1, 8)]
	public int octaves = 1;
	[Range(1f, 4f)]
	public float lacunarity = 2f;
	[Range(0f, 1f)]
	public float persistence = 0.5f;
	[Range(1, 3)]
	public int dimensions = 3;
	public int radius = 1;
	public Gradient coloring;
	
	public NoiseParam(int resolution,float strength,bool damping,float frequency,int octaves,float lacunarity,float persistence,int dimensions,int radius)
	{
		this.resolution = resolution;
		this.strength =  strength;
		this.damping = damping;
		this.frequency = frequency;
		this.octaves = octaves;
		this.lacunarity = lacunarity;
		this.persistence = persistence;
		this.dimensions = dimensions;
		this.radius = radius;
	}//*/
}
